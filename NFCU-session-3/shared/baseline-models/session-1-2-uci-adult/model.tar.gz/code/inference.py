# ABOUTME: SageMaker sklearn-container inference handlers for the UCI Adult model.
# ABOUTME: Loads the joblib pipeline and serves CSV in / CSV (proba,label) out.
import io
import os

import joblib
import pandas as pd

FEATURES = ["age", "workclass", "education_num", "marital_status",
            "occupation", "race", "sex", "hours_per_week"]


def model_fn(model_dir):
    return joblib.load(os.path.join(model_dir, "model.joblib"))


def input_fn(request_body, content_type="text/csv"):
    if content_type != "text/csv":
        raise ValueError(f"Unsupported content type: {content_type}")
    rows = [line for line in request_body.strip().splitlines() if line]
    data = [dict(zip(FEATURES, r.split(","))) for r in rows]
    df = pd.DataFrame(data)
    for col in ["age", "education_num", "hours_per_week"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


def predict_fn(df, model):
    proba = model.predict_proba(df)[:, 1]
    label = (proba > 0.5).astype(int)
    return list(zip(proba.tolist(), label.tolist()))


def output_fn(prediction, accept="text/csv"):
    return "\n".join(f"{p:.6f},{l}" for p, l in prediction), "text/csv"
